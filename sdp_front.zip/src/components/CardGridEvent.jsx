import React, { useState } from "react";
import CardEvent from "./CardEvent";
import ModalEvent from "./ModalEvent";
import "../components/css/CardGrid.css";

const CardGridEvent = ({ cardsData }) => {
  const [selectedCard, setSelectedCard] = useState(null);

  const handleCardClick = (card) => {
    setSelectedCard(card);
  };

  const closeModal = () => {
    setSelectedCard(null);
  };

  return (
    <div>
      <div className="cards-grid">
        {cardsData.map((card) => (
          <CardEvent
            key={card.id}
            image={card.image}
            title={card.title}
            description={card.description}
            button_title="View Details"
            onClick={() => handleCardClick(card)}
          />
        ))}
      </div>
      {selectedCard && (
        <ModalEvent isOpen={!!selectedCard} onClose={closeModal} card={selectedCard} />
      )}
    </div>
  );
};

export default CardGridEvent;
