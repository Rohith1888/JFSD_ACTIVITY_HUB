import React from "react";
import Banner from "./Banner";
import CardGridEvent from "./CardGridEvent";
import "../components/css/events.css";

// Static images
import flutter from "../Assets/images/flutter.jpg";
import genai from "../Assets/images/genai.jpg";
import gamedev from "../Assets/images/gamedev.jpg";
import webdev from "../Assets/images/webdev.jpg";
import data from "../Assets/images/data.jpg";
import wordpress from "../Assets/images/wordpress.jpg";
import food from "../Assets/images/food.jpg";
import standup from "../Assets/images/standup.jpg";
import social from "../Assets/images/social.jpg";
import photography from "../Assets/images/photography.jpg";
import arts from "../Assets/images/arts.jpg";

export default function Events() {
  const technicalEvents = [
    { id: 1, image: flutter, title: "Flutter", description: "Flutter is Google's UI toolkit for building natively compiled applications for mobile, web, and desktop." },
    { id: 2, image: genai, title: "Gen AI", description: "Gen AI can generate convincingly authentic images, videos, and audio of real people." },
    { id: 3, image: gamedev, title: "Game Development", description: "Game development starts from an idea or concept and transforms into immersive experiences." },
    { id: 4, image: webdev, title: "Web Development", description: "Web development is the overall process of creating websites or web applications." },
    { id: 5, image: data, title: "Dive into Data Science", description: "Data science combines tools, methods, and technology to generate meaning from data." },
    { id: 6, image: wordpress, title: "WordPress", description: "WordPress is a free, open-source platform for website creation." },
  ];

  const nonTechnicalEvents = [
    { id: 7, image: food, title: "Food", description: "Competitive eating events challenge participants to eat large quantities in a short time." },
    { id: 8, image: standup, title: "Standup Comedy", description: "Stand-up comedy is a live performance delivering humor to audiences." },
    { id: 9, image: social, title: "Social Service", description: "Social services provide assistance and support to particular groups in need." },
    { id: 10, image: photography, title: "Photography", description: "Photography is about capturing light to create memorable and expressive images." },
    { id: 11, image: arts, title: "Arts and Crafts", description: "Arts and crafts involve creating things with your own hands, fostering creativity." },
  ];

  return (
    <>
      <Banner title1="Events" title2="" />
      <h2 className="center-heading">Technical Events</h2>
      <CardGridEvent cardsData={technicalEvents} />
      <h2 className="center-heading">Non-Technical Events</h2>
      <CardGridEvent cardsData={nonTechnicalEvents} />
    </>
  );
}
