import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import AddIcon from '@mui/icons-material/Add';
import RefreshIcon from '@mui/icons-material/Refresh';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  DataGrid,
  GridToolbarContainer,
} from '@mui/x-data-grid';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import axios from 'axios';

function EditToolbar(props) {
  const { setAddDialogOpen, handleRefresh } = props;

  return (
    <GridToolbarContainer>
      <Button color="primary" startIcon={<AddIcon />} onClick={() => setAddDialogOpen(true)}>
        Add Event
      </Button>
      <Button color="secondary" startIcon={<RefreshIcon />} onClick={handleRefresh}>
        Refresh
      </Button>
    </GridToolbarContainer>
  );
}

export default function FullFeaturedCrudGrid() {
  const [rows, setRows] = React.useState([]);
  const [addDialogOpen, setAddDialogOpen] = React.useState(false);
  const [clubs, setClubs] = React.useState([]);
  const [selectedClubId, setSelectedClubId] = React.useState('');
  const [students, setStudents] = React.useState([]);
  const [newEventName, setNewEventName] = React.useState('');
  const [newDescription, setNewDescription] = React.useState('');
  const [newDate, setNewDate] = React.useState('');
  const [newTime, setNewTime] = React.useState('');
  const [newVenue, setNewVenue] = React.useState('');
  const [newOrganizerEmail, setNewOrganizerEmail] = React.useState('');

  // Fetch events from server
  const fetchEvents = async () => {
    try {
      const response = await axios.get('http://localhost:8080/admin/getAllEvents');
      setRows(response.data);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast.error('Failed to fetch events.');
    }
  };

  // Fetch all clubs from the server
  const fetchClubs = async () => {
    try {
      const response = await axios.get('http://localhost:8080/admin/getAllClubs');
      setClubs(response.data);
    } catch (error) {
      console.error('Error fetching clubs:', error);
      toast.error('Failed to fetch clubs.');
    }
  };

  React.useEffect(() => {
    fetchEvents();
    fetchClubs();
  }, []);

  // Fetch students for the selected club
  const fetchStudents = async (clubId) => {
    try {
      const response = await axios.get(`http://localhost:8080/admin/${clubId}/students`);
      setStudents(response.data);
      console.log(response.data);
      
    } catch (error) {
      console.error('Error fetching students:', error);
      toast.error('Failed to fetch students.');
    }
  };

  // Handle refresh button click
  const handleRefresh = () => {
    fetchEvents();
  };

  // Add new event
  const handleAddEvent = async () => {
    if (
      !newEventName ||
      !selectedClubId ||
      !newOrganizerEmail ||
      !newDescription ||
      !newDate ||
      !newTime ||
      !newVenue
    ) {
      toast.error('Please fill all the fields.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8080/admin/addEvent', {
        eventName: newEventName,
        eventDescription: newDescription,
        eventDate: newDate,
        eventTime: newTime,
        eventVenue: newVenue,
        club: { id: selectedClubId },
        organizer: { email: newOrganizerEmail },
      });

      if (response.data === 'Event already exists') {
        toast.error('Event already exists.');
      } else {
        fetchEvents();
        setAddDialogOpen(false);
        // Reset form fields
        setNewEventName('');
        setSelectedClubId('');
        setNewOrganizerEmail('');
        setNewDescription('');
        setNewDate('');
        setNewTime('');
        setNewVenue('');
        toast.success('Event added successfully!');
      }
    } catch (error) {
      console.error('Error adding event:', error);
      toast.error('There was an error adding the event.');
    }
  };

  // Define columns for the DataGrid
  const columns = [
    { field: 'eventId', headerName: 'ID', width: 100, editable: false },
    { field: 'eventName', headerName: 'Event Name', width: 200, editable: true },
    { field: 'eventDescription', headerName: 'Description', width: 250, editable: true },
    { field: 'eventDate', headerName: 'Date', width: 150, editable: true },
    { field: 'eventTime', headerName: 'Time', width: 150, editable: true },
    { field: 'eventVenue', headerName: 'Venue', width: 200, editable: true },
    {
      field: 'clubId',
      headerName: 'Club',
      width: 200,
      valueGetter: (params) => {
        return params.row.club ? params.row.club.name : 'No Club';  // Ensure club exists
      },
    },
    {
      field: 'organizerEmail',
      headerName: 'Organizer',
      width: 200,
      valueGetter: (params) => {
        return params.row.organizer ? params.row.organizer.email : 'No Organizer';  // Ensure organizer exists
      },
    },
  ];

  return (
    <>
      <ToastContainer />
      <Box
        sx={{
          height: 650,
          width: '100%',
          '& .actions': { color: 'text.secondary' },
          '& .textPrimary': { color: 'text.primary' },
        }}
      >
        <Typography variant="h5" className="heading">
          Events
        </Typography>
        <DataGrid
          rows={rows}
          columns={columns}
          editMode="row"
          slots={{ toolbar: EditToolbar }}
          slotProps={{ toolbar: { setAddDialogOpen, handleRefresh } }}
        />
        <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)}>
          <DialogTitle>Add New Event</DialogTitle>
          <DialogContent>
            <TextField
              label="Event Name"
              required
              fullWidth
              value={newEventName}
              onChange={(e) => setNewEventName(e.target.value)}
              style={{ marginBottom: '15px' }}
            />
            <TextField
              select
              label="Club"
              required
              fullWidth
              value={selectedClubId}
              onChange={(e) => {
                setSelectedClubId(e.target.value);
                fetchStudents(e.target.value);
              }}
              style={{ marginBottom: '15px' }}
            >
              {clubs.map((club) => (
                <MenuItem key={club.id} value={club.id}>
                  {club.name}
                </MenuItem>
              ))}
            </TextField>
            <TextField
  select
  label="Organizer"
  required
  fullWidth
  value={newOrganizerEmail}
  onChange={(e) => setNewOrganizerEmail(e.target.value)}
  style={{ marginBottom: '15px' }}
>
  {students.length === 0 ? (
    <MenuItem value="">
      No students exist in this club
    </MenuItem>
  ) : (
    students.map((student) => (
      <MenuItem key={student.email} value={student.email}>
        {student.fullName} 
      </MenuItem>
    ))
  )}
</TextField>

            <TextField
              label="Description"
              required
              fullWidth
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              style={{ marginBottom: '15px' }}
            />
            <TextField
              label="Date"
              required
              type="date"
              fullWidth
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              style={{ marginBottom: '15px' }}
            />
            <TextField
              label="Time"
              required
              type="time"
              fullWidth
              value={newTime}
              onChange={(e) => setNewTime(e.target.value)}
              InputLabelProps={{ shrink: true }}
              style={{ marginBottom: '15px' }}
            />
            <TextField
              label="Venue"
              required
              fullWidth
              value={newVenue}
              onChange={(e) => setNewVenue(e.target.value)}
              style={{ marginBottom: '15px' }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setAddDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddEvent}>Save</Button>
          </DialogActions>
        </Dialog>
      </Box>
    </>
  );
}
